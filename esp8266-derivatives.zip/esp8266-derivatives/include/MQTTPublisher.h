#pragma once
#include "Config.h"
#include "MotionState.h"
#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

/**
 * MQTTPublisher
 * -------------
 * Serialises a MotionState to JSON and publishes it to the MQTT broker.
 * Handles reconnection transparently.
 *
 * JSON payload shape:
 * {
 *   "t":  1234567,      // timestamp ms (relative to boot)
 *   "x":  523.4,        // position mm
 *   "v":  -102.3,       // velocity mm/s
 *   "a":  58.1,         // acceleration mm/s²
 *   "dt": 50.1          // actual Δt used for the derivative (ms)
 * }
 */
class MQTTPublisher {
public:
    MQTTPublisher() : _mqtt(_wifiClient) {}

    void begin() {
        _mqtt.setServer(MQTT_HOST, MQTT_PORT);
        _mqtt.setBufferSize(512);
        _connect();
    }

    // Call every loop iteration — handles keepalive and reconnection
    void loop() {
        if (!_mqtt.connected()) _connect();
        _mqtt.loop();
    }

    bool publish(const MotionState& s) {
        if (!_mqtt.connected()) return false;

        // Build compact JSON — stack allocated, no heap fragmentation
        StaticJsonDocument<128> doc;
        doc["t"]  = s.timestamp_ms;
        doc["x"]  = roundf(s.position_mm  * 10.0f) / 10.0f; // 1 decimal
        doc["v"]  = roundf(s.velocity_mms * 10.0f) / 10.0f;
        doc["a"]  = roundf(s.accel_mms2   * 10.0f) / 10.0f;
        doc["dt"] = roundf(s.dt_ms        * 10.0f) / 10.0f;

        char buf[128];
        size_t len = serializeJson(doc, buf);
        return _mqtt.publish(TOPIC_MOTION, buf, len);
    }

    bool connected() const { return _mqtt.connected(); }

private:
    WiFiClient   _wifiClient;
    PubSubClient _mqtt;
    uint32_t     _last_attempt_ms = 0;

    void _connect() {
        if (millis() - _last_attempt_ms < 5000) return; // backoff
        _last_attempt_ms = millis();

        Serial.print("[MQTT] Connecting to ");
        Serial.print(MQTT_HOST);
        Serial.print("...");

        bool ok = _mqtt.connect(MQTT_CLIENT_ID, MQTT_USER, MQTT_PASS);
        if (ok) {
            Serial.println(" connected!");
        } else {
            Serial.print(" failed, rc=");
            Serial.println(_mqtt.state());
        }
    }
};
